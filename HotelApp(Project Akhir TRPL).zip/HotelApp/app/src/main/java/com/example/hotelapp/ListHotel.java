package com.example.hotelapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ListHotel extends AppCompatActivity  implements RecyclerViewInterface{
    RecyclerView recyclerView;
    HotelAdapter adapter;

    List<Hotel> hotelList;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_list);

        final TextView cin = (TextView) findViewById(R.id.text_checkin);
        final TextView cout = (TextView) findViewById(R.id.text_checkout);
        final TextView kam = (TextView) findViewById(R.id.kamar);

        Intent intent = getIntent();
        String output1 = intent.getStringExtra("checkin");
        String output2 = intent.getStringExtra("checkout");
        String output3 = intent.getStringExtra("kamar");

        cin.setText("Tanggal Check - In = " + output1);
        cout.setText("Tanggal Check - Out = " + output2);
        kam.setText("Jumlah Kamar yang Dipesan = " + output3);

        hotelList = new ArrayList<>();
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        hotelList.add(
                new Hotel(
                        1, "Hotel Baru Bangun",
                        "Deskripsi ini merupakan deskripsi untuk Hotel Baru Bangun. Fasilitasnya seperti ini dan itu",
                        "Rp. 1.050.000,- / malam",
                        R.drawable.hotel1)
                );
        hotelList.add(
                new Hotel(
                        1, "Hotel Udah Lama Bangun",
                        "Deskripsi ini merupakan deskripsi untuk Hotel Udah Lama Bangun. Fasilitasnya seperti ini dan itu",
                        "Rp. 2.000.000,- / malam",
                        R.drawable.hotel2)
        );
        hotelList.add(
                new Hotel(
                        1, "Hotel Hampir Bangun",
                        "Deskripsi ini merupakan deskripsi untuk Hotel Hampir Bangun. Fasilitasnya seperti ini dan itu",
                        "Rp. 1.500.000,- / malam",
                        R.drawable.hotel3)
        );
        hotelList.add(
                new Hotel(
                        1, "Hotel Gajadi Bangun",
                        "Deskripsi ini merupakan deskripsi untuk Hotel Gajadi Bangun. Fasilitasnya seperti ini dan itu",
                        "Rp. 1.000.000,- / malam",
                        R.drawable.hotel4)
        );
        hotelList.add(
                new Hotel(
                        1, "Hotel Tiba - Tiba Bangun",
                        "Deskripsi ini merupakan deskripsi untuk Hotel Tiba - Tiba Bangun. Fasilitasnya seperti ini dan itu",
                        "Rp. 1.750.000,- / malam",
                        R.drawable.hotel5)
        );
        adapter = new HotelAdapter(this, hotelList, this);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(this, HotelDesc.class);

        intent.putExtra("nama", hotelList.get(position).getName());
        intent.putExtra("desc", hotelList.get(position).getShortDesc());
        intent.putExtra("harga", hotelList.get(position).getPrice());
        intent.putExtra("img", hotelList.get(position).getImage());

        startActivity(intent);
    }
}