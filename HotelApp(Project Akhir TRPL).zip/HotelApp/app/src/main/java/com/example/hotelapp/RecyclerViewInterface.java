package com.example.hotelapp;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
